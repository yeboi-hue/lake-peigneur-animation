# Lake Peigneur Short — Build Notes

- Composition: `LakePeigneurShort`
- Authored canvas: 1080 × 1920 (9:16)
- Default final export: 1440 × 2560 (2K vertical), 30 FPS, H.264 CRF 16
- Duration: narration-driven; the audio script computes exact frame duration and shot starts.
- Audio: generated narration, original atmospheric score, and synthesized effects via `scripts/make_audio.py`.
- Rendering: GitHub Actions matrix rendering with 12/16/20 balanced chunks (12 by default), software WebGL (`swangle`), concurrency 2 per runner, and a 360-minute per-chunk timeout.
- Output artifact: `lake-peigneur-mp4` containing `lake-peigneur.mp4`; chunk artifacts are temporary and retained for one day.

The workflow is configured to render only when manually dispatched or pushed to `main`. No render was run while preparing this source package.

## Quality-preservation policy

Do not reduce scene detail, geometry, texture quality, lighting, shadows, post-processing, animation duration, frame count, or audio quality to solve timeouts. Optimize code and workflow resource use first. The `--scale=1.3333`, 30 FPS, and CRF 16 settings are the default.


## Parallel-rendering integrity

- Each chunk receives an inclusive, non-overlapping frame range calculated from the exact narration-generated total frame count.
- Every chunk uses the same scale, frame rate, codec, CRF, WebGL backend, and composition.
- Chunk renders are muted; the generated full-length narration/music/SFX mix is muxed exactly once after stream-copy concatenation.
- The assembly job checks the final frame count and confirms exactly one audio stream.
- Matrix jobs may queue if the GitHub account's concurrent-runner allowance is lower than the requested matrix size.
