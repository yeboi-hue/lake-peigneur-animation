# Lake Peigneur — The Lake That Swallowed a Drilling Rig

A roughly 60-second vertical animated short built with **Remotion + Three.js + React Three Fiber**. The story is an original reenactment of the November 20, 1980 Lake Peigneur disaster in Louisiana.

## Render on GitHub Actions — parallel chunks, original quality

The GitHub Actions workflow renders the animation in **12, 16, or 20 parallel frame chunks** (12 by default), then joins the video streams without re-encoding and attaches the complete audio track exactly once.

The final production settings remain:
- 1440 × 2560 (vertical 2K)
- 30 FPS
- H.264, CRF 16
- Full narration-driven duration and every frame
- Original scene geometry, textures, lighting, shadows, ink, lens blur, bloom, grading, and animation

### If you upload the extracted project

Upload the contents of this ZIP to the repository root, including the hidden `.github` folder. The workflow at `.github/workflows/render.yml` will then be available in GitHub Actions.

### If you upload only the ZIP file

GitHub does not activate workflow files stored inside an unextracted ZIP. Upload `LakePeigneur-Short-COMPLETE.zip` to the repository root, and separately create `.github/workflows/render.yml` in the repository using the companion workflow file `docs/RENDER_WORKFLOW_ZIP_ROOT.yml` from this package.

The workflow supports both the extracted project and the ZIP-upload layout. It recognizes `LakePeigneur-Short-COMPLETE.zip` and `LakePeigneur-Short.zip`.

### Run the workflow

1. Open **Actions → Render Lake Peigneur Short (Parallel, Quality Preserved)**.
2. Choose **Run workflow**.
3. Select 12, 16, or 20 chunks. Start with 12; larger counts are not guaranteed to run simultaneously because GitHub concurrency depends on account and repository limits.
4. Wait for the prepare, chunk-render, and assembly jobs to finish.
5. Download the `lake-peigneur-mp4` artifact from the successful workflow run.

The chunks render silently, then FFmpeg concatenates them in frame order using stream copy. The original generated narration/music/SFX mix is attached once at the end. The workflow verifies the expected frame count and exactly one audio stream.

**Important:** Parallel jobs can reduce elapsed time when GitHub has enough runner capacity, but they do not guarantee a fixed speedup. The workflow does not reduce resolution, frame rate, CRF quality, shadow resolution, or post-processing effects. A longer job timeout prevents premature termination; it does not itself make rendering faster.

## Local commands (optional)

```bash
npm install
python -m pip install edge-tts numpy
# Install ffmpeg and espeak-ng on your operating system.
npm run audio
npm run dev
npm run render
```

## Project structure

```text
.github/workflows/render.yml      Cloud rendering + MP4 artifact upload
scripts/make_audio.py             Narration, original music/SFX mix, shot timing
requirements.txt                  Python audio-generation dependencies
public/                           Generated audio and timing are created here in CI
src/index.ts                      Remotion entry point
src/Root.tsx                      Composition registration and dynamic duration
src/videos/lakepeigneur/
  LakePeigneur.tsx                Main Remotion composition and camera rig
  story.ts                        Shot plan, camera path, transitions and timing helpers
  world.ts / world-scene.tsx      3D environment and animated disaster set pieces
  build.ts                        Shared low-poly geometry helpers
  toon.ts                         Original hand-drawn character texture generator
  cast.ts / cast-cards.tsx        Lit 2D character billboards in the 3D world
  lights.ts                       Day, storm and golden-hour lighting presets
  shade.ts                        Shared palette
  ink.ts / grade.ts               Outline material and final color grade
  lensblur.ts                     Thin-lens depth-of-field passes
```

## Production notes

- No captions or on-screen labels; narration carries the story.
- The characters and environments are original stylized reenactments, not archival footage.
- The story uses shot timing generated from the actual narration clips, so visual beats follow the voice.
- The audio generator uses an online neural voice when available and falls back to `espeak-ng` if it cannot connect.
- The composition is designed for a vertical 9:16 frame and uses smooth camera glides, dutch tilts, a brief impact flash, atmospheric fog, warm/cool lighting shifts, animated water, the drilling platform, barges, an underground mine cross-section, thin-lens depth of field, and restrained emissive bloom.

## Research and factual notes

The short is based on historical accounts from the University of Louisiana at Lafayette Special Collections, the Mine Safety and Health Administration's Jefferson Island mine inundation report, and contemporary 1980 reporting. The exact cause and responsibility were disputed in contemporary reporting; the script describes the physical sequence without assigning blame.

Sources:
- University of Louisiana at Lafayette, Special Collections: https://library.louisiana.edu/node/2548
- MSHA, *Report of Mine Inundation* (Jefferson Island, 1980): https://usminedisasters.miningquiz.com/saxsewell/1980_jefferson_island.pdf
- UPI Archives, November 21, 1980: https://www.upi.com/Archives/1980/11/21/Drilling-rig-breaks-into-salt-mine-cavity-draining-lake/6665343630800/
- UPI Archives, November 28, 1980: https://www.upi.com/Archives/1980/11/28/Gas-well-flame-goes-out-at-salt-dome-site/4517344235600/

## Rendering policy

The source project and GitHub Actions workflow are provided. The video is not rendered or exported in this workspace; GitHub Actions creates the MP4 artifact after the project is uploaded.
